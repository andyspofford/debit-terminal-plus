#!/bin/bash

# Ensure yad is installed
if ! command -v yad &> /dev/null; then
  echo "yad not found. Please install it first: sudo apt install yad"
  exit 1
fi

# Get clipboard contents as default path
DEFAULT_PATH=$(xclip -o -selection clipboard 2>/dev/null)
[ -z "$DEFAULT_PATH" ] && DEFAULT_PATH="$HOME"

# Show the toggle GUI
result=$(yad --form --width=400 --title="Terminal Plus Options" \
  --field="Open in Directory":DIR "$DEFAULT_PATH" \
  --field="Enable iPhone SOCKS5 Proxy":CHK FALSE \
  --field="Terminal Mode:CB" 'Regular!No Log!Save Log in Documents!Venv Sandboxed!Root!Sudo Everything')

# Parse the result
IFS="|" read -r directory socks_enabled terminal_mode <<< "$result"

# Proxy config
proxy_cmd=""
[ "$socks_enabled" = "TRUE" ] && proxy_cmd="env all_proxy=socks5://172.20.10.1:9876"

# Terminal command mapping
case "$terminal_mode" in
  "Regular")
    term_cmd="xfce4-terminal --working-directory=\"$directory\""
    ;;
  "No Log")
    term_cmd="xfce4-terminal --disable-server --hold --working-directory=\"$directory\""
    ;;
  "Save Log in Documents")
    term_cmd="xfce4-terminal --command=\"script ~/Documents/terminal_log_$(date +%Y%m%d_%H%M%S).txt\" --working-directory=\"$directory\""
    ;;
  "Venv Sandboxed")
    term_cmd="bash -c 'source ~/my_venv/bin/activate && xfce4-terminal --working-directory=\"$directory\"'"
    ;;
  "Root")
    term_cmd="xfce4-terminal --command=\"sudo -i\" --working-directory=\"$directory\""
    ;;
  "Sudo Everything")
    term_cmd="xfce4-terminal --command='bash -c \\\"echo alias sudo=\\\\\\\"sudo \\\\\\\" >> ~/.bashrc && exec bash\\\"' --working-directory=\"$directory\""
    ;;
esac

# Launch the terminal with optional proxy
eval $proxy_cmd $term_cmd
